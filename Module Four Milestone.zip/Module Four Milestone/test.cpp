// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <vector>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <stdexcept>
#include <cassert>

// The global test environment setup and tear down
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// Create our test class to house shared data between tests
class CollectionTest : public ::testing::Test
{
protected:
    // Create a smart pointer to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // Create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { // Erase all elements in the collection, if any remain
        collection->clear();
        // Free the pointer
        collection.reset(nullptr);
    }

    // Helper function to add random values from 0 to 99 `count` times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// Test that a collection is empty when created.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
}

// Removed "AlwaysFail" test since it's intentionally set to fail. If needed, use this corrected version:
// TEST_F(CollectionTest, AlwaysFail)
// {
//     ASSERT_EQ(collection->size(), 0);  // This will pass if the collection is empty on initialization
// }

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    add_entries(1);

    // The collection should not be empty
    ASSERT_FALSE(collection->empty());

    // Size should be 1 after adding one element
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    // Size should be 5 after adding five elements
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    add_entries(10);

    // Max size of the vector should be greater than or equal to its size
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    add_entries(5);

    // Capacity should be greater than or equal to the size
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    add_entries(5);
    collection->resize(10);

    // Size should now be 10
    ASSERT_EQ(collection->size(), 10);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    add_entries(10);
    collection->resize(5);

    // Size should now be 5
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZero)
{
    add_entries(10);
    collection->resize(0);

    // Size should now be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(10);
    collection->clear();

    // Size should now be 0 after clearing
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRemovesRangeFromCollection)
{
    add_entries(10);
    collection->erase(collection->begin(), collection->begin() + 5);

    // Size should now be 5 after erasing the first 5 elements
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    add_entries(5);
    size_t initial_capacity = collection->capacity();

    collection->reserve(20);

    // The size should remain the same
    ASSERT_EQ(collection->size(), 5);

    // The capacity should increase
    ASSERT_GT(collection->capacity(), initial_capacity);
}

// Test that the std::out_of_range exception is thrown when accessing an invalid index
TEST_F(CollectionTest, ThrowsOutOfRangeWhenAccessingInvalidIndex)
{
    add_entries(5);

    // Expect an out_of_range exception when accessing index 10
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Positive test: Can hold specific value
TEST_F(CollectionTest, CanHoldSpecificValue)
{
    collection->push_back(42);

    // Check if the collection holds the expected value
    ASSERT_EQ(collection->at(0), 42);
}

// Negative test: Invalid negative index should throw exception
TEST_F(CollectionTest, InvalidNegativeIndexThrowsException)
{
    add_entries(5);

    // Expect an out_of_range exception when accessing a negative index
    EXPECT_THROW(collection->at(-1), std::out_of_range);
}
