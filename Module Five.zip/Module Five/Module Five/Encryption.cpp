#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

// Function to encrypt or decrypt a source string using the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();       // Get key length
    const auto source_length = source.length(); // Get source length

    assert(key_length > 0);     // Ensure key length is valid
    assert(source_length > 0);  // Ensure source length is valid

    std::string output = source;

    // Loop through the source string character by character
    for (size_t i = 0; i < source_length; ++i)
    {
        // Perform XOR encryption
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length); // Ensure output length matches source length

    return output; // Return the transformed string
}

// Function to read the content of a text file into a string
std::string read_file(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return "";
    }

    std::stringstream buffer;
    buffer << file.rdbuf(); // Read the entire file into a stringstream
    return buffer.str(); // Convert stringstream to string
}

// Function to extract the student name from the string data
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    size_t pos = string_data.find('\n'); // Find the first newline character
    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos); // Extract the student name
    }
    return student_name;
}

// Function to save data to a file in the specified format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << filename << std::endl;
        return;
    }

    // Get current date using localtime_s for safety
    std::time_t now = std::time(nullptr);
    std::tm now_tm;
    localtime_s(&now_tm, &now);

    std::stringstream date_ss;
    date_ss << (now_tm.tm_year + 1900) << "-" << std::setw(2) << std::setfill('0') << (now_tm.tm_mon + 1) << "-" << std::setw(2) << std::setfill('0') << now_tm.tm_mday;

    // Write data to file in the specified format
    file << student_name << "\n";
    file << date_ss.str() << "\n";
    file << key << "\n";
    file << data;
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";           // Name of the input data file
    const std::string encrypted_file_name = "encrypteddatafile.txt"; // Name of the encrypted data file
    const std::string decrypted_file_name = "decrytpteddatafile.txt"; // Name of the decrypted data file
    const std::string key = "password"; // Key to use for encryption and decryption

    const std::string source_string = read_file(file_name); // Read the input data file
    const std::string student_name = get_student_name(source_string); // Extract the student name

    const std::string encrypted_string = encrypt_decrypt(source_string, key); // Encrypt the source string
    save_data_file(encrypted_file_name, student_name, key, encrypted_string); // Save the encrypted string to a file

    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key); // Decrypt the encrypted string
    save_data_file(decrypted_file_name, student_name, key, decrypted_string); // Save the decrypted string to a file

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
